#ifndef SMART_ARRAY_H
#define SMART_ARRAY_H  

/*    @file SmartArray.cpp   
      @author < Fill Me In >
      @date < Fill Me In >

			@description Implements a class for an array with bounds checking.
      Implementatoin is below the declaration in this same file.
*/

#include <string>
#include <sstream>
#include <stdexcept>


using namespace std;

template <typename T>
class SmartArray{
  public:
  
  SmartArray();   // Default is T().
  SmartArray(T);  // Defines a different default value.
  SmartArray(const SmartArray<T> &);  // The {}; implements this until you do below.
  ~SmartArray();
  SmartArray<T>& operator=(const SmartArray<T> &other);

  T& operator[](int);       // Set data in array, NO negatives

  int size() const;  // Return the number of elements in the SmartArray
  
  SmartArray<T> operator+(const SmartArray<T> &) const;  // Append this to the other, return new one
  bool operator==(const SmartArray &) const;  // Are they the same?
  int count(T) const;   // How many times does this element exist?
  
  string getAsString() const;
  
  void sort();
  
  private:
  
  T* data;
  unsigned array_size;
  T default_value;
  bool sorted;
};
/*                   Implementation       */
template <class T>
ostream& operator<<(ostream &o, const SmartArray<T> &r){
  o << r.getAsString();
  return o;
}

template <class T>
SmartArray<T>::SmartArray(){
  array_size = 0;
  data = NULL;
  default_value = T();
  sorted = true;
}

template <class T>
SmartArray<T>::SmartArray(T value){
  array_size = 0;
  data = NULL;
  default_value = value;
  sorted = true;
}

template <class T>
SmartArray<T>::SmartArray(const SmartArray<T> &other){
  array_size = other.array_size;
  default_value = other.default_value;
  sorted = other.sorted;
  if(other.data == NULL){
    data = NULL;
    return;
  }
  data = new T[array_size];
  for(unsigned i = 0; i < array_size; i++){
    data[i] = other.data[i];
  }
}

template <class T>
SmartArray<T>::~SmartArray(){
  if(data){
    delete[] data;
    data = NULL;
  }
}

template <class T>
SmartArray<T>& SmartArray<T>::operator=(const SmartArray &other){
  delete[] data;
  data = NULL;
  array_size = other.array_size;
  default_value = other.default_value;
  if(other.data == NULL){
    data = NULL;
    return *this;
  }
  data = new T[array_size];
  for(unsigned i = 0; i < array_size; i++){
    data[i] = other.data[i];
  }
  sorted = other.sorted;
  return *this;
}

template <class T>
T& SmartArray<T>::operator[](int location){
  if(location < 0){
    throw logic_error("Negative not allowed");
  }
  if(data == NULL){
    data = new T[location + 1];
    array_size = location + 1;
    for(unsigned i = 0; i < array_size; i++){
      data[i] = default_value;
    }
    sorted = false;
    return data[location];
  }else{
    if(location >= array_size){
      T* temp = new T[location + 1];
      for(unsigned i = 0; i < location + 1; i++){
        temp[i] = default_value;
      }
      for(unsigned i = 0; i < array_size; i++){
        temp[i] = data[i];
      }
      delete[] data;
      data = temp;
      array_size = location + 1;
    }
    sorted = false;
    return data[location];
  }
  
}

template <class T>
string SmartArray<T>::getAsString() const{
  stringstream s;
  s << "[";
  for(unsigned i = 0; i < array_size; i++){
    s << data[i];
    if(i != array_size - 1){
      s << ", ";
    }
  }
  s << "]";
  return s.str();
}

template <class T>
int SmartArray<T>::size() const{
  return array_size;
}

template <class T>
int SmartArray<T>::count(T thing) const{
  int c = 0;
  for(unsigned i = 0; i < array_size; i++){
    if( data[i] == thing)c++;
  }
  return c;
}

template <class T>
bool SmartArray<T>::operator==(const SmartArray &other) const{
  if(array_size != other.array_size)return false;
  for(unsigned i = 0; i < array_size; i++){
    if( data[i] != other.data[i])return false;
  }
  return true;
}

template <class T>
SmartArray<T> SmartArray<T>::operator+(const SmartArray &other) const{
  SmartArray<T> ret;
  ret.default_value = default_value;
  ret.array_size = array_size + other.array_size;
  ret.data = new T[ret.array_size];
  for(unsigned i = 0; i < array_size; i++){
    ret.data[i] = data[i];
  }
  for(unsigned i = 0; i < other.array_size; i++){
    ret.data[i + array_size] = other.data[i];
  }
  return ret;
}

template <class T>
int Partition(T numbers[], int i, int k) {
   int l;
   int h;
   int midpoint;
   T pivot;
   T temp;
   bool done;
   
   /* Pick middle element as pivot */
   midpoint = i + (k - i) / 2;
   pivot = numbers[midpoint];
   
   done = false;
   l = i;
   h = k;
   
   while (!done) {
      
      /* Increment l while numbers[l] < pivot */
      while (numbers[l] < pivot) {
         ++l;
      }
      
      /* Decrement h while pivot < numbers[h] */
      while (pivot < numbers[h]) {
         --h;
      }
      
      /* If there are zero or one elements remaining,
       all numbers are partitioned. Return h */
      if (l >= h) {
         done = true;
      }
      else {
         /* Swap numbers[l] and numbers[h],
          update l and h */
         temp = numbers[l];
         numbers[l] = numbers[h];
         numbers[h] = temp;
         
         ++l;
         --h;
      }
   }
   
   return h;
}

template <class T>
void Quicksort(T numbers[], int i, int k) {
   int j;

   /* Base case: If 1 or zero elements,
      partition is already sorted */
   if (i >= k) {
      return;
   }

   /* Partition the array.
      Value j is the location of last
      element in low partition. */
   j = Partition(numbers, i, k);

   /* Recursively sort low and high     
       partitions */
   Quicksort(numbers, i, j);
   Quicksort(numbers, j + 1, k);
}

template <class T>
void SmartArray<T>::sort(){
  Quicksort(data, 0, array_size - 1);
}

#endif

