/*    @file vehicle-sandbox.cpp    
      @author <fill me in>
      @date <fill me in>  

			@description Sandbox for the Bicycle, Car, Truck and Airplane classes
*/

#include <iostream>


#include "vehicle.h"

using namespace std;

int main(int argc, char* argv[]){
  // Use this program to test your implementation!
  
  
}
 
