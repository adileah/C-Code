/* 
Adileah Smith
csci 156 - summer term
Homework 1
*/
#include <iostream>

using namespace std;

main() {
    cout << "Hello World! Enter a number pleeeeeaaaase." << endl; //printf
    int number = 0; 
    cin >> number; //scanf
    cout << "Number: " << number << endl;
    
}