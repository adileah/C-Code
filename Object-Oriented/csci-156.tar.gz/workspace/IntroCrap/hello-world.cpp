#include <iostream>

using namespace std;

main() {
    cout << "Hello World!" << endl; //printf
    int number = 0; 
    cin >> number; //scanf
    cout << "Number: " << number << endl;
    /*for loop same but can declare variable in loop; only can use variable in loop
    can use boolians but actual names as type bool so bool a = true/false
    can also declare ints as true or false
    can have functions named same thing but different requirements in () and it recognizes on its own
    /like string, string or string integer/
    c9 opens file from command line
    */
}
